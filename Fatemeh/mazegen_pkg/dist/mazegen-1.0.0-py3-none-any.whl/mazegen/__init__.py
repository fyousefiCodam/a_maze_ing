from mazegen.maze_generator import MazeGenerator

__all__ = ["MazeGenerator"]
__version__ = "1.0.0"
